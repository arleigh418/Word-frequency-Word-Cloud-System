from flask import Flask, request, render_template, redirect, url_for
import pandas as pd
from flask import render_template
from flask import request
import jieba
import re
import codecs
from collections import Counter
import os
from PIL import Image
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator
from os import path
import numpy as np
from flask import send_file, send_from_directory
import datetime
# import segment
# import json
from pymongo import MongoClient
# from wordcloud import (WordCloud, get_single_color_func)
from random import Random
import os
import sys
import colorsys
from operator import itemgetter

# from PIL import Image
from PIL import ImageColor
# from PIL import ImageDraw
# from PIL import ImageFilter
# from PIL import ImageFont

app = Flask(__name__)
# app.config['SEND_FILE_MAX_AGE_DEFAULT'] = timedelta(seconds=0.01)
# app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(seconds=0.01)
# app.config["CACHE_TYPE"] = "null"


def get_single_color_func(color):
    """Create a color function which returns a single hue and saturation with.
    different values (HSV). Accepted values are color strings as usable by
    PIL/Pillow.
    >>> color_func1 = get_single_color_func('deepskyblue')
    >>> color_func2 = get_single_color_func('#00b4d2')
    """
    old_r, old_g, old_b = ImageColor.getrgb(color)
    rgb_max = 255.
    h, s, v = colorsys.rgb_to_hsv(old_r / rgb_max, old_g / rgb_max,
                                  old_b / rgb_max)

    def single_color_func(word=None, font_size=None, position=None,
                          orientation=None, font_path=None, random_state=None):
        """Random color generation.
        Additional coloring method. It picks a random value with hue and
        saturation based on the color given to the generating function.
        Parameters
        ----------
        word, font_size, position, orientation  : ignored.
        random_state : random.Random object or None, (default=None)
          If a random object is given, this is used for generating random
          numbers.
        """
        # if random_state is None:
        #     random_state = Random()
        r, g, b = colorsys.hsv_to_rgb(h, s, v)#random_state.uniform(1, 1))
        return 'rgb({:.0f}, {:.0f}, {:.0f})'.format(r * rgb_max, g * rgb_max,
                                                    b * rgb_max)
    return single_color_func

class GroupedColorFunc(object):
    """Create a color function object which assigns DIFFERENT SHADES of
       specified colors to certain words based on the color to words mapping.

       Uses wordcloud.get_single_color_func

       Parameters
       ----------
       color_to_words : dict(str -> list(str))
         A dictionary that maps a color to the list of words.

       default_color : str
         Color that will be assigned to a word that's not a member
         of any value from color_to_words.
    """

    def __init__(self, color_to_words, default_color):
        self.color_func_to_words = [
            (get_single_color_func(color), set(words))
            for (color, words) in color_to_words.items()]

        self.default_color_func = get_single_color_func(default_color)

    def get_color_func(self, word):
        """Returns a single_color_func associated with the word"""
        try:
            color_func = next(
                color_func for (color_func, words) in self.color_func_to_words
                if word in words)
        except StopIteration:
            color_func = self.default_color_func

        return color_func

    def __call__(self, word, **kwargs):
        return self.get_color_func(word)(word, **kwargs)

@app.route("/freq2", methods=['POST','GET'])
def freq2():
    if request.method == 'POST':
        myFile = request.files.get('myfile', None)
        client = MongoClient('52.221.109.165', 28288)
        db = client.inner_tool
        db.authenticate("inner_tool_service", "Asia_Inner_Service")
        data = pd.read_excel(myFile)
        data.to_excel("pre_load.xlsx")
        jieba.load_userdict('./new_words.txt')

        new_word = []
        with open('new_words.txt', 'r', encoding='UTF-8') as file:
            for text_word in file.readline():
                text_word = text_word.strip()
                new_word.append(text_word)
        

        
        wb = data['內文']
        wb=wb.values.tolist()
        wb_str = str(wb)
        # wb_str = wb_str.replace("高+<><","高加魚")
        byebyeword = "[\s+\.\!\/_,$%^*~(+\"\')]~,-|[——()?『\』；【】“”！，。？、~@#￥%……&*（）●:[\]「」=：.!',-/' ]"

        word= re.sub(byebyeword,'',wb_str)
        print(word) 

        g1 = open('text_forword_excel.txt','w')
        g1.write(word)
        g1.close()

        stopWords = []
        segments=[]
        remainderWords=[]
        with open('stop_words.txt', 'r', encoding='UTF-8') as file:
            for data in file.readlines():
                data = data.strip()
                stopWords.append(data)       
    
        with open('text_forword_excel.txt', 'r') as file:
            text_forword_excel = file.read()
            segments = jieba.cut(text_forword_excel, cut_all=False)

        remainderWords = list(filter(lambda a: a not in stopWords and a != '\n', segments))

        wb_join = "".join('%s'%id for id in remainderWords)




        # wb_join = wb_join.replace("高+<><","高加魚")

        # byebyeword = "[\s+\.\!\/_,$%^*~(+\"\')]~,-|[——()?『\』；【】“”！，。？、~@#￥%……&*（）●:[\]「」=：.!',-/' ]"

        # word= re.sub(byebyeword,'',wb_join)
        # print(word1)

        # f1 = open('text.txt','w')
        # f1.write(word)
        # f1.close()

        # with codecs.open('text.txt', 'r') as f:
        #      txt = f.read()
        seg_list = jieba.cut(wb_join)
        c = Counter()
        for x in seg_list:
            # x = x.replace("高加魚","高+<><")
            if len(x)>=1:
                c[x] += 1
        print('詞頻統計結果')
        df = pd.DataFrame()
        af = pd.DataFrame()
        
        
        for (k,v) in c.most_common(10):
        
            af = af.append([[k,v]])
            
        #print(df)

        
      
        for (k,v) in c.most_common():       
            df = df.append([[k,v]])
        df.index = range(len(df))
        df.columns = ['名詞','詞頻']    
        print(df)
        
        df.to_excel('./詞頻.xlsx',index=False)
        lst87=af.values.tolist() #or to json
        
        return render_template('freq2_d.html', lst87=lst87)
    return render_template('freq2.html')

# 吃 檔案名下載
@app.route("/download/<filename>", methods=['GET', 'POST'])
def download_file(filename):
    print('進來download')
    # print(tables)
    if request.values['file_name']=='':
        print('沒選前')
        print(filename)
        file_name = '還不命名9487.xlsx'
        # print('沒選後')
        # print(filename)
        
    else:
        file_name = request.values['file_name'] +'.xlsx'
        print(file_name)
        
    out = './'+filename
    print('下載前')
    print(out)

    # return send_from_directory(directory, file_name, as_attachment=True)
    return send_file(out, as_attachment=True, attachment_filename=file_name)


# 文字雲三 調參數 產文字雲
@app.route("/cloud3_download/<read_file_name>", methods=['POST','GET'])
def cloud3_select(read_file_name):
    if request.method == 'POST':
        # 讀本機檔
        word_fre_file = './'+ read_file_name
        word_fre_data = pd.read_excel(word_fre_file)
        # 抓標籤
        label = word_fre_data['標籤']
        # label_for_color = label
        label = label.drop_duplicates(keep='first', inplace=False)
        label = label.tolist()
        print(label)
        # 抓選取的顏色
        color_pick = request.form.getlist('color_pick')
        # 將標籤&顏色編成dict
        label_color = {}
        for i in range(len(color_pick)):
            label_color[label[i]] = color_pick[i]
        # 做成 文字雲要吃的 color_to_words
        color_to_words ={}
        # print(label_for_color.index)
        # print(word_fre_data.index)
        for k,v in label_color.items():
            column_data = word_fre_data[word_fre_data['標籤']==k]
            column_data = column_data['名詞'].tolist()
            color_to_words[v] = column_data

        # 產文字雲
        cloud_word_frequen = word_fre_data[['名詞','詞頻']]
        cloud_dict = {}
        for word,frequen in cloud_word_frequen.values:
            cloud_dict[word] = frequen

        wc= WordCloud(font_path="./static/font/NotoSansCJKtc-Black.otf", #設置字體 #要自由切換字體 4、5種
                    background_color="white", #背景顏色
                    max_words = 2000,
                    width=200, height=180,
                    scale=10,  
                    mask=None,
                    # stopwords=stopwords
                    )
        wc.generate_from_frequencies(frequencies = cloud_dict)
        default_color = '#000000'
        grouped_color_func = GroupedColorFunc(color_to_words, default_color)
        wc.recolor(color_func=grouped_color_func)
        pic_path = './static/images/label_color.jpg'
        wc.to_file(pic_path)

        download_file_path =  pic_path

        file_name = request.values['file_name'] +'.jpg'
        # 選完 post 直接下載
        return send_file(download_file_path, as_attachment=True, attachment_filename=file_name)
    # 還沒post 讓他選參數的頁面
    return render_template('cloud3_d.html')

# 文字雲三 上傳詞頻檔案
@app.route("/cloud3_upload", methods=['POST','GET'])
def cloud3_upload():
    # myFile = request.files.get('excelFile', None)
    if request.method == 'POST':
        myFile = request.files.get('excelFile', None)
        # myFile = request.files['excelFile']
        # output_file_name 是存檔案在資料夾 提供後面存取
        # 頁面要加說明 讓使用者上傳檔案前 檔名加上自己的名字 避免後端檔案衝突
        output_file_name = myFile.filename
        word_fre = pd.read_excel(myFile)
        word_fre.to_excel(output_file_name)
        print(word_fre.head())
        label = word_fre['標籤']
        label.drop_duplicates(keep='first', inplace=True)
        label = label.tolist()
        # print(label)

        
        return render_template('cloud3_d.html', column_color=label, read_file_name=output_file_name)
    return render_template('cloud3.html')


# # 走資料庫的文字雲 黑名白名
# @app.route("/segment", methods=['POST','GET'])
# def mongo_segment():

#     # list 
#     record = segment.record_list()
#     channel= segment.channel_list()
#     group = segment.channel_web()

#     if request.method == 'POST':
#         # request.headers.get('Content-Type') == 'application/json'
#         data = json.loads(request.data)
#         if data['type'] == 'form':
            
#             # 新增紀錄 
#             rec_id = segment.ins_record(data)

#             # 調用異部處理
#             rec_id = tasks.task_segment.delay(data, rec_id)
#             # segment.main(data,rec_id)
#             return request.data

#         elif data['type'] == 'del':

#             status = segment.del_record(data['id'])
#             return json.dumps(status)   
#     else: 
#         # return record
#         # return render_template('segment.html', record = record, channel = channel, group = group)
#         return render_template('db_cloud.html', record = record, channel = channel, group = group)

# # segment 內部工具 allen
# @app.route('/segment', methods=['POST','GET'])
# def route_segment():

#     # list 
#     record = segment.record_list()
#     channel= segment.channel_list()
#     group = segment.channel_web()

#     if request.method == 'POST':
#         # request.headers.get('Content-Type') == 'application/json'
#         data = json.loads(request.data)
#         if data['type'] == 'form':
            
#             # 新增紀錄 
#             rec_id = segment.ins_record(data)

#             # 調用異部處理
#             rec_id = tasks.task_segment.delay(data, rec_id)
#             # segment.main(data,rec_id)
#             return request.data

#         elif data['type'] == 'del':

#             status = segment.del_record(data['id'])
#             return json.dumps(status)   
#     else: 
#         # return record
#         return render_template('segment.html', record = record, channel = channel, group = group)


# index
@app.route('/', methods=['POST','GET'])
def route_index():
    return render_template('index.html')

@app.route("/logout")
def logout():
    return "暫時的登出!"

@app.route("/download_frequency", methods=['GET', 'POST'])
def download_frequency():
	print('進來download')
	# file_name = request.values['file_name'] +'.xlsx' # 需要知道2个参数, 第1个参数是本地目录的path, 第2个参数是文件名(带扩展名)
	# directory = os.getcwd()  # 假设在当前目录
	file_name = '詞頻.xlsx'
	out = './詞頻.xlsx'

	# return send_from_directory(directory, file_name, as_attachment=True)
	return send_file(out, as_attachment=True, attachment_filename=file_name)

@app.route("/download_image", methods=['GET', 'POST'])
def download_image():
	print('進來download')
	# file_name = request.values['file_name'] +'.xlsx' # 需要知道2个参数, 第1个参数是本地目录的path, 第2个参数是文件名(带扩展名)
	# directory = os.getcwd()  # 假设在当前目录
	img_name = 'wordcloud.jpg'
	out = './static/images/wordcloud.jpg'

	# return send_from_directory(directory, file_name, as_attachment=True)
	return send_file(out, as_attachment=True, attachment_filename=img_name)

# @app.after_request
# def add_header(response):
#     """
#     Add headers to both force latest IE rendering engine or Chrome Frame,
#     and also to cache the rendered page for 10 minutes.
#     """
#     response.headers['X-UA-Compatible'] = 'IE=Edge,chrome=1'
#     response.headers['Cache-Control'] = 'public, max-age=0'
#     return response

@app.route('/cloud_generate', methods=['GET', 'POST'])
def cloud_generate():
    # @after_this_request
    # def add_header(response):
    #     """
    #     Add headers to both force latest IE rendering engine or Chrome Frame,
    #     and also to cache the rendered page for 10 minutes.
    #     """
    #     response.headers['X-UA-Compatible'] = 'IE=Edge,chrome=1'
    #     response.headers['Cache-Control'] = 'public, max-age=0'
    #     return response
    myFile = request.files.get('myfile', None)
    # datetime = datetime.now()
    # print(datetime)
    # myFile = request.files['myfile']
    # print('my_file')
    # print(myFile)
    if myFile == None and request.method == 'POST':

        # word_choose = request.POST.get('all_word', None)
        # print("all_word")
        # print(word_choose)
        text_font = request.values['text_font']
        pic = request.values['pic']

        # text_font = request.POST.get('text_font', None)
        # pic = request.POST.get('pic', None)
    
        # for word_bee,word_imgg in word_choose:
        if text_font == "word_black":              
            word_bee = "./static/font/NotoSansCJKtc-Black.otf" 
                        
        elif text_font == "word_bold":
            word_bee = "./static/font/NotoSansCJKtc-Bold.otf"
        
        elif text_font == "word_light":
            word_bee = "./static/font/NotoSansCJKtc-Light.otf"
        elif text_font == "word_medium":
            word_bee = "./static/font/NotoSansCJKtc-Medium.otf"
        else:
            word_bee = None

        if pic == "img_1":
            pic_type = 'pica'
            word_imgg = "./static/images/pica.jpg"
        elif pic == "img_2":
            pic_type = 'labi'
            word_imgg = "./static/images/labi.jpg"
        elif pic == "img_3":
            pic_type = 'egg'
            word_imgg = "./static/images/egg.jpg"
        elif pic == "img_4":
            pic_type = 'snoopy'
            word_imgg = "./static/images/snoopy.jpg"
        elif pic == "img_5":
            pic_type = 'sudichi'
            word_imgg = "./static/images/sudichi.jpg"
        else:
            pic_type = 'normal'
            word_imgg = None

        # print(word_bee)
        # print(word_imgg)

        #print(myFile)
        myFile = 'pre_load.xlsx'
        data = pd.read_excel(myFile)
        jieba.load_userdict('./保留字.txt')
        data_fre = pd.read_excel('./詞頻.xlsx')
        data_fre = data_fre[:10]
        lst87=data_fre.values.tolist()
        
        # wb = data['內文']
        # # print(wb.head())
        # wb=wb.values.tolist()
        # wb_join = "".join('%s'%id for id in wb)
        # wb_join = wb_join.replace("高+<><","高加魚")

        # byebyeword = "[\s+\.\!\/_,$%^*(+\"\')]|[——()?【】“”！，。？、~@#￥%……&*（）●:「」=：]"
        # words = jieba.cut(wb_join,cut_all=False)
        # word="".join(words)
        # word1= re.sub(byebyeword,'',word)
        # to_remove = ['"2018""-0"5""-04""的""說""就是""也不會""我""妳""你""了""在""再""到""與""沒""有""人""讓""為""要""都""來""但""他""看""們""後""長""自己""把""一個""嗎""被""只""Re""更""去""這"']
        # to_remove = str(to_remove)
        # table = str.maketrans("","",to_remove)
        # new_one = word1.translate(table)
        
        
        # # stopwords = {}.fromkeys(["就是","一個","什麼","那個","不是","自己","可以","不會","可能","怎麼","非常","哪裡","趕快","一樣","一直","真的","不要","他們","我們","還是","http"])  
        if word_imgg == None:
            alice_coloring = None
    
        else:
            d = os.path.dirname(os.path.realpath('__file__'))
            # print(d)
            alice_coloring = np.array(Image.open(path.join(d, word_imgg)))
            # print(path.join(d, word_imgg))
        
    
        # 產生文字雲
        wocal = pd.read_excel('./詞頻.xlsx')

        yaya_wc = {}
        for g,z in wocal.values:
            yaya_wc[g]=z
        
        

        
        wc= WordCloud(font_path=word_bee, #設置字體 #要自由切換字體 4、5種
                    background_color="white", #背景顏色
                    max_words = 2000,
                    width=200, height=180,
                    scale=10,  
                    mask=alice_coloring,
                    # stopwords=stopwords
                    )
        wc.generate_from_frequencies(frequencies = yaya_wc)        

        
        # if word_imgg != None:
        #     image_colors = ImageColorGenerator(alice_coloring)
        
        # 視覺化
        # plt.imshow(wc, interpolation="bilinear")
        # plt.axis("off")
        # if pic_type=='pica':
        # 	pic_path = './static/images/pica_0.jpg'
        # 	wc.to_file(pic_path)
        # elif pic_type=='labi':
        # 	pic_path = './static/images/labi_0.jpg'
        # 	wc.to_file(pic_path)
        # elif pic_type=='egg':
        # 	pic_path = './static/images/egg_0.jpg'
        # 	wc.to_file(pic_path)
        # elif pic_type=='snoopy':
        # 	pic_path = './static/images/snoopy_0.jpg'
        # 	wc.to_file(pic_path)
        # elif pic_type=='sudichi':
        # 	pic_path = './static/images/sudichi_0.jpg'
        # 	wc.to_file(pic_path)
        # else:
        # 	pic_path = './static/images/87_0.jpg'
        # 	wc.to_file(pic_path)
        pic_path = './static/images/'+text_font+'_'+pic_type+'.jpg'
        wc.to_file(pic_path)
        
        # 存檔
        # wc.to_file('./static/images/wordcloud.jpg')
        img_name="images/"+ text_font +"_"+ pic_type +".jpg"
        # wc.to_file('./static/images/wordcloud2.jpg')

        # return render_template('one.html',lst87=lst87,condi=condi,pic_type=pic_type,text_font=text_font)
        return render_template('one.html',lst87=lst87,img_name=img_name)
        # return redirect(url_for('cloud_generate'))	

    elif request.method == 'POST':
        data = pd.read_excel(myFile)
        data.to_excel("pre_load.xlsx")
        jieba.load_userdict('./保留字.txt')

        wb = data['內文']
        wb=wb.values.tolist()
        wb_join = "".join('%s'%id for id in wb)
        wb_join = wb_join.replace("高+<><","高加魚")
        byebyeword = "[\s+\.\!\/_,$%^*(+\"\')]|[——()?【】“”！，。？、~@#￥%……&*（）●:「」=：]"

        words = jieba.cut(wb_join,cut_all=False)
        word="".join(words)
        word1= re.sub(byebyeword,'',word)
        to_remove = ['"2018""-0"5""-04""的""說""就是""也不會""我""妳""你""了""在""再""到""與""沒""有""人""讓""為""要""都""來""但""他""看""們""後""長""自己""把""一個""嗎""被""只""Re""更""去""這"']
        to_remove = str(to_remove)
        table = str.maketrans("","",to_remove)
        new_one = word1.translate(table)
        
        f1 = open('text.txt','w')
        f1.write(new_one)
        f1.close()

        with codecs.open('text.txt', 'r') as f:
             txt = f.read()
        seg_list = jieba.cut(txt)
        c = Counter()
        for x in seg_list:
            x = x.replace("高加魚","高+<><")
            if len(x)>=0:
                c[x] += 1
        print('詞頻統計結果')
        df = pd.DataFrame()
        af = pd.DataFrame()
        
        
        for (k,v) in c.most_common(10):
        
            af = af.append([[k,v]])
            
        #print(df)

        
      
        for (k,v) in c.most_common():
        
            df = df.append([[k,v]])
        df.index = range(len(df))
        df.columns = ['名詞','詞頻']    
        print(df)
        
        df.to_excel('./詞頻.xlsx',index=False)
        lst87=af.values.tolist() #or to json
        # condi='see'
        
        return render_template('one.html',lst87=lst87) 
    else:
        
        return render_template('one.html')


if __name__ == "__main__":
    app.run(debug=True)