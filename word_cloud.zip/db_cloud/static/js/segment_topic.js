$(function(){
	var pageParam = {
        next: '.next',//下一页按钮jq选择器
        prev: '.prev',//上一页按钮jq选择器
        nextMore: '.nextMore',//下n页按钮jq选择器
        prevMore: '.prevMore',//上n页按钮jq选择器
        totalEl: '.total',//总页数jq元素  元素内包含 eq:“共n页”
        curPageEl: '.cur_page',//当前页数jq元素  元素内包含 eq:“当前第n页”
        perPageCount: 10,//每页显示数量
        morePage: 5//上、下n页跳转数
    }
    //demo为包裹列表的容器
    $('.datatable').find('.record').page(pageParam);



	$(':file').change(function(){
		var file = this.files[0]; //定義file=發生改的file
		name = file.name; //name=檔案名稱
		size = file.size; //size=檔案大小
		type = file.type; //type=檔案型態
		if(file.size > 30000000) { //假如檔案大小超過300KB (300000/1024)
			alert('圖片上限30MB!!'); //顯示警告!!
			$(this).val('');  //將檔案欄設為空白
		}else if(file.type != 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' && file.type != 'application/vnd.ms-excel'){ //檔案格式
			alert('檔案格式不符合:xls、xlsx'); //顯示警告
			console.log(file.type)
			$(this).val(''); //將檔案欄設為空
		}
	});


	$('.submit').on("click",function(){

		$('.submit').attr("disabled","disabled");
		if(!$('input[name="name"]').val()){
			alert('請輸入名稱')
			$('.submit').removeAttr("disabled")
			return false
		}else if(!$('#upload').val()){
			alert('請上傳檔案')
			$('.submit').removeAttr("disabled")
			return false
		}else{
			$('#form').submit()
		}
	})

	$('.delBtn').click(function(){
		var id = $(this).closest('tr').attr('data-id');
		if(confirm('確定刪除此筆資料??')){
			$.ajax({
	            type : "POST",
	            url : "/segment_topic",
	            contentType: 'application/json;charset=UTF-8',
				data:JSON.stringify({
					'type':'del',
					'id':id,
				}),
				success:function(result){
	                console.log(result);
					alert('刪除成功。')
					// location.reload()
				}
			});
		}
	});	
})

