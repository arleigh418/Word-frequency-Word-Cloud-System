$(function(){

	var pageParam = {
        next: '.next',//下一页按钮jq选择器
        prev: '.prev',//上一页按钮jq选择器
        nextMore: '.nextMore',//下n页按钮jq选择器
        prevMore: '.prevMore',//上n页按钮jq选择器
        totalEl: '.total',//总页数jq元素  元素内包含 eq:“共n页”
        curPageEl: '.cur_page',//当前页数jq元素  元素内包含 eq:“当前第n页”
        perPageCount: 10,//每页显示数量
        morePage: 5//上、下n页跳转数
    }
    //demo为包裹列表的容器
    $('.datatable').find('.record').page(pageParam);

    var $lightbox = $('.lightbox');

    $('.channel_button').on('click', function(e){
    	$lightbox.fadeIn(300);
        // e.preventdefault();
    });

    $lightbox,$('.closeBtn').on('click', function(){

    	$('.channel_button').val()

        $lightbox.fadeOut(300);
    });


    $('.lbContent').on('click', function(evt){
        evt.stopPropagation();
    });  

    $('.channel_search').change(function(){
    	$('.group_scr p').show()
    	$('.scroll div').hide()
    	$('.scroll div p').show()
    	if($(this).val()){
    		$('.scroll div p').hide()
  			$('.group_scr p').hide()
  			$('label:contains('+$(this).val()+')').each(function() {
  				$('.group_scr p input[id=web_'+$(this).parent().parent().data('group')+']').parent('p').show()
  			});
  			// $('.group_scr p input[id=web_'+$('label:contains('+$(this).val()+')').parent().parent().data('group')+']').parent('p').show()
    		$('label:contains('+$(this).val()+')').parent('p').show()

    	}
    })

    $('.scroll').find('input').change(function(){
    	// 已選擇

		$('.select_scr').html('')
		var keys=[]
		$('.lightbox .scroll').find('input[name="channel"]:checked').each(function() {
			keys.push($(this).val())
		});

		for(var i = 0 ; i < keys.length ; i++){			
			$('.select_scr').append('<p>'+keys[i]+'</p>')
		}

    	// 粗體
    	if($(this).parent('p').parent('div').find('input[type=checkbox]:checked').length >= 1)
    		$('.group_scr p input[id=web_'+$(this).parent('p').parent('div').data('group')+']').next('label').css('font-weight','bold')
    	else 
    		$('.group_scr p input[id=web_'+$(this).parent('p').parent('div').data('group')+']').next('label').css('font-weight','')
    });

	$('#upload').change(function(){$('[name=file]').val($(this).val())});


	$('[name=check_all]').click(function(){
	    $(this).parent('p').parent('div').find('p input').not(this).prop('checked', $(this).prop("checked"));
	})

	$('.group').click(function(){
		$('.lbContent .scroll div').css('display','none')
	    $('div[data-group="'+$(this).attr('name')+'"]').css('display','block')
	})


	var id = 8;
	$('.submit').on("click",function(){

		$('.submit').attr("disabled","disabled");


		var error = 0
		var search = $('#search');

		if(!search.find('input[name="name"]').val()){
			alert('請輸入議題名稱')
			$('.submit').removeAttr("disabled")
			return false
		}else
			$('#form1 input[name="name"]').val(search.find('input[name="name"]').val())

		if($('.lightbox .lbContent .scroll').find('input:checked').length==0){
			alert('請選擇頻道')
			$('.submit').removeAttr("disabled")
			return false
		}else{
			$('#form1 input[name=channel]').remove()
			var t = 0
			var keys=[]
			$('.lightbox .scroll').find('input[name="channel"]:checked').each(function() {
				keys.push($(this).val())
			});
			keys.sort(function(a,b){
				return a - b
			});
			for(var i = 0 ; i < keys.length ; i++){			
				$('#form1').append('<input type="hidden" name="channel\['+i+'\]" value="'+keys[i]+'">')
			}
		}
		if(!search.find('input[name="starttime"]').val()){
			alert('請選擇資料開始時間')
			$('.submit').removeAttr("disabled")
			return false
		}else
			$('#form1 input[name="starttime"]').val(search.find('input[name="starttime"]').val())

		if(!search.find('input[name="endtime"]').val()){
			alert('請選擇資料結束時間')
			$('.submit').removeAttr("disabled")
			return false
		}else
			$('#form1 input[name="endtime"]').val(search.find('input[name="endtime"]').val())


		$('.wb').remove()
		var white = $('.white').val().split('\n')
		if($('.white').val().length > 0){
			for(i = 0 ; i < white.length ; i++){
				if(white[i]!=''){
					$('#form1').append('<input type="hidden" name="white\['+i+'\]" value="'+white[i]+'" class="wb">')
				}
			}			
		}else{
			alert('請輸入白名單')
			$('.submit').removeAttr("disabled")
			return false
		}

		var black = $('.black').val().split('\n')
		if($('.black').val().length > 0){
			for(i = 0 ; i < black.length ; i++){
				if(black[i]!=''){
					$('#form1').append('<input type="hidden" name="black\['+i+'\]" value="'+black[i]+'" class="wb">')
				}
			}			
		}else{
			alert('請輸入黑名單')
			$('.submit').removeAttr("disabled")
			return false
		}
		

		// 條件搜尋 
		var set = 0;
		var yes = 0;
		var no  = 0;
		var not = 0;
		$('#form1').find('.kw').remove()

		var keywords = $('.keywords').val().split('\n')
		if($('.keywords').val() != ''){
			for(i = 0 ; i < keywords.length ; i++){
				temp_ary = keywords[i].split('&')
				yes = 0
				no = 0
				// 分割後把正的放yes
				for(j = 0 ; j < temp_ary.length ; j++){
					if(temp_ary[j]!=''){
						temp_not = temp_ary[j].split('-')
						$('#form1').append('<input type="hidden" name="keywords\['+i+'\]\[yes\]\['+yes+'\]" value="'+temp_not[0]+'" class="kw">')
						yes++
						// 除了第一個後面都是 no
						for(k = 1 ; k < temp_not.length ; k++){
							$('#form1').append('<input type="hidden" name="keywords\['+i+'\]\[no\]\['+no+'\]" value="'+temp_not[k]+'" class="kw">')
							no++
						}						
					}
				}
			}			
		}else{
			alert('請輸入搜尋關鍵字')
			$('.submit').removeAttr("disabled")
			return false	
		}

		var data = $('#form1').serializeObject()
	    $.ajax({
            type : "POST",
            url : "/segment",
            enctype: 'multipart/form-data',
            contentType: 'application/json;charset=UTF-8',
            data:JSON.stringify(data),
            success: function(result) {
                console.log(result);
                alert('送出成功。')
                location.reload()
            }
        });			
		


	})

	$('.delBtn').click(function(){
		var id = $(this).closest('tr').attr('data-id');
		if(confirm('確定刪除此筆資料??')){
			$.ajax({
	            type : "POST",
	            url : "/segment",
	            contentType: 'application/json;charset=UTF-8',
				data:JSON.stringify({
					'type':'del',
					'id':id,
				}),
				success:function(result){
	                console.log(result);
					alert('刪除成功。')
					location.reload()
				}
			});
		}
	});


});	
