from flask import Flask, request, render_template, redirect, url_for
from flask import request
from flask import send_file, send_from_directory
import datetime
import numpy as np
import pandas as pd
import re
import jieba
import sys
import colorsys
from operator import itemgetter
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator
from PIL import Image
from PIL import ImageColor
import os
from pymongo import MongoClient
client = MongoClient('52.221.109.165', 28288)
from bson.objectid import ObjectId
from collections import Counter


app = Flask(__name__)

# 話題列表_下載 詞頻_上傳檔案_下載
# 下載excel用
@app.route("/download/<filename>", methods=['GET', 'POST'])
def download_file(filename):
	# 抓檔案名
	file_name = request.values['file_name'] +'.xlsx'
	# 抓檔案  前一個頁面透過板塊傳來的輸出檔案路徑
	output_file = './'+filename
	
	return send_file(output_file, as_attachment=True, attachment_filename=file_name)

# 話題列表
@app.route("/talk", methods=['GET', 'POST'])
def talk():
    if request.method == 'POST':
        # 抓 Indexasia 資料庫 用途不同 使用的資料庫也不同
        db = client.Indexasia
        # 驗證資料庫帳密
        db.authenticate("", "")

        #頻道->
        # 先做出 channel 對應用的df
        # 接收input 選取日期 跟 輸出的檔案名稱
        channel_input = request.values['channel_name']
        date_input = request.values['date_fil']
        
        # 頻道 編成字典 供資料撈取時對應使用
        # 把輸入頻道編成dict
        channel_dict = {}
        channel_input_split = channel_input.replace(" ","").split(',')
        for i in range(len(channel_input_split)):
            channel_dict[i] = channel_input_split[i]
        
        # 把符合選取頻道的資料抓出來 存list
        channel_list = []
        for i in range(len(channel_dict)):
            # 撈資料 符合選取的頻道 然後只取 '_id','tw_type','tw_name' 三個欄位
            cursor = db.channel.find({'tw_name':channel_dict[i]},{'_id','tw_type','tw_name'}) #選資料表 collection && 要篩選的欄位(頻道 etc.)
            # 先丟list 最後一次轉df 效率比較好 欄位對應問題也已解決
            for document in cursor:
                channel_list.append(document)
        #不用指定欄位 他會抓原本資料裡的
        df_channel = pd.DataFrame(channel_list)

        # 日期->
        # 前端進來的數據樣本:
        # "2018-07-12 - 2018-08-08"
        # 為了區分下載檔案用的變數
        data_count = 0

        # 選了日期 然後分成 開始日期 跟 結束日期
        date_input_split = date_input.split()
        # 結束日期 補上 23:59:59 才會抓到結束日期 最後一個時間點的資料
        end_2359 = date_input_split[2]+' 23:59:59'

        start_date = datetime.datetime.strptime(date_input_split[0],'%Y-%m-%d')
        end_date = datetime.datetime.strptime(end_2359,'%Y-%m-%d %H:%M:%S')

        # 一樣 先把post抓出來的資料丟list 比較有效率
        post_list = []
        for k in range(len(df_channel)):
            # 對應選取的頻道(頻道可能全選) 把資料抓取 只呈現 'title','date','comment_count','url','author'
            cursor = db.post.find({'channel_id':df_channel['_id'][k],'date':{'$gte': start_date, '$lte': end_date}},
            	{'title','date','comment_count','url','author','channel_id'})
            # 區分下載檔案用的變數
            data_count = data_count + cursor.count()
            # 先丟list 最後一次轉df 效率比較好 欄位對應問題也已解決
            for document in cursor:
                post_list.append(document)
        # list 轉df            
        df_post = pd.DataFrame(post_list)
        df_channel = df_channel.rename(columns={'_id':'channel_id'})
        # 將df_post, df_channel 合併成為需要的資料
        df_result = pd.merge(df_post,df_channel, on='channel_id')

        # 將整理後的欄位 更名為 希望呈現的名稱
        df_result = df_result.rename(columns={'title':'內文','date':'發文時間','comment_count':'回應數',
        	'url':'網址','author':'發文ID','tw_type':'網站類型','tw_name':'來源頻道'})
        # 將整理後的欄位 排序為 希望呈現的順序
        df_result = df_result.reindex(columns=['網站類型','內文','發文ID','發文時間','回應數','來源頻道','網址'])	           

        # 輸出excel 檔案位置可再更改 給他特殊檔案名 資料筆數+現在時間.xlsx 避免覆蓋問題
        file_name = str(data_count)+ datetime.datetime.now().strftime("%Y%m%d%H%M%S") + ".xlsx"
        # 輸出供下載
        df_result.to_excel(file_name)

        #目前是df直接輸出html呈現 但很醜 可能要再想別的呈現方式 (可以用tolist 或其他樣式 ex.json 一樣用前端模塊包住)
        return render_template('話題列表_下載.html', tables=df_result.to_html(classes='data'), file_name=file_name)
    
    # 一開始進入的頁面 選完 提交post 才執行上面的結果
    else:
        # 只是get 沒提交任何資料
        # df_channel_fil = pd.DataFrame()
        return render_template('話題列表.html')#, df_channel_fil = df_channel_fil)

# 詞頻_上傳檔案
@app.route('/word_frequency_file', methods=['GET', 'POST'])
def word_frequency_file():
    if request.method == 'POST':
        #讀取前端的檔案
        myFile = request.files.get('excelFile')
        # 抓 inner_tool 資料庫
        db = client.inner_tool
        db.authenticate("inner_tool_service", "Asia_Inner_Service")
        #以LIST抓取資料庫保留字
        save_list = list(db.save_word.find({},{'word'}))
        #將資料存成Dataframe
        df_save= pd.DataFrame(save_list)
        #僅保留文字的部分
        save_them = df_save['word']
        #存成LIST供後面使用
        save_word = list(save_them)

        #將停用字換行存成txt檔案，之所以要換行是因為jieba.load_userdict讀取的檔案規則
        save_txt = open('save.txt','w',encoding = 'utf-8')
        for line in save_word:
            save_txt.write(line)
            save_txt.write('\n')
        save_txt.close()

        #結巴指定切詞，例如"再"and"下雨阿" ， 指定切成"再下雨阿"
        jieba.load_userdict('save.txt') 

        #以LIST抓取資料庫停用字
        stop_list = list(db.stop_word.find({},{'word'}))
        df_stop= pd.DataFrame(stop_list)
        stop_them = df_stop['word']
        stop_word = list(stop_them)

        data = pd.read_excel(myFile)
        #讀取EXCEL，並處理名叫"內文"的欄位
        wb = data['內文']
        wb=wb.values.tolist() #存成LIST供後面使用
        wb_str = "".join(str(wb)) #也存成str供後面使用

        save_word_space = []
        #將保留字從wb_str中提出並放到save_word_space裡，並刪除wb_str中的保留字，避免重複計算
        for x in save_word:
            if x in wb_str:
                x_count = wb_str.count(x)
                for xc in range(x_count):
                    save_word_space.append(x)
                wb_str = wb_str.replace(x,'') 

        segments=[]
        #將處理好的wb_str先做結巴，並放置segments中
        segments = jieba.cut(wb_str,cut_all=False)
        #如果segments中有停用字，將之移除
        remainderWords = list(filter(lambda a: a not in stop_word and a != '\n', segments))
    
        #整理remainderWords
        wb_final = "".join('%s'%id for id in remainderWords)
        #設置不需要的符號
        byebyeword = "[\s+\.\!\/_,$%^*(+\"\')],-|[——()?【】“”！\]\[\；\』\『\《\》\\\︿\，。？、~@#￥%……&*（）●:「」=：.!,'-\<\+\>\/ ]"
        #移除不需要的符號
        final_word= re.sub(byebyeword,'',wb_final)

        #將先前的保留字放回 準備統一計算詞頻
        for z in save_word_space:
            final_word+=z

        #結巴
        seg_list = jieba.cut(final_word)
        #計算詞頻
        c = Counter()
        for x in seg_list:
            if len(x)>=0:
                c[x] += 1

        #存成dataframe準備存成excel檔
        df = pd.DataFrame()
        for (k,v) in c.most_common():
            df = df.append([[k,v]])
    
        df.index = range(len(df))
        df.columns = ['名詞','詞頻']
        # 區分檔案名稱 加上當時時間當檔名
        output_file_name = myFile.filename.split('.')[0] + datetime.datetime.now().strftime("%Y%m%d%H%M%S") + '.xlsx'
        df.to_excel(output_file_name,index=False)

        return render_template('詞頻_上傳檔案_下載.html', read_file_name=output_file_name)

    else:
        return render_template('詞頻_上傳檔案.html')


# 文字雲_預設圖_下載 吃前一頁面存檔的檔案名 選字體 圖片 產文字雲 直接下載
@app.route("/cloud_default_download/<read_file_name>", methods=['POST','GET'])
def cloud_default_download(read_file_name):
    if request.method == 'POST':
        # 選擇字體
        # 沒選的話 預設黑體
        text_font = request.values.get('fonttype','word_black')
        if text_font == "word_light":
            cloud_font = "./static/font/NotoSansCJKtc-Light.otf"
        else:
            cloud_font = "./static/font/NotoSansCJKtc-Black.otf"
        # 上傳圖片 沒特別選的話 預設圓形(文字雲圖形)
        cloud_imgg = request.values.get('pic_type', 'circle')
        # 如果要擴增預設圖 前端加選項 這裡加elif 照相同邏輯更改
        if cloud_imgg == "normal":
            pic_mask = None
        else:
            pic_mask = "./static/images/circle.jpg"
        
        # 讀本機檔 檔案名是前一頁面下載的檔案名
        word_fre_file = './'+ read_file_name
        word_fre_data = pd.read_excel(word_fre_file)
        
        # 整理出要製成文字雲的詞頻 做成dict
        cloud_word_frequen = word_fre_data[['名詞','詞頻']]
        cloud_dict = {}
        for word,frequen in cloud_word_frequen.values:
            cloud_dict[word] = frequen

        # 處理文字雲遮罩(圖片)
        if pic_mask == None:
            mask = None
        else:
            d = os.path.dirname(os.path.realpath('__file__'))
            mask = np.array(Image.open(os.path.join(d, pic_mask)))
        # 產文字雲
        wc= WordCloud(font_path=cloud_font, #設置字體 #要自由切換字體 4、5種
                    background_color="white", #背景顏色
                    max_words = 50,
                    width=1000, height=860,  
                    mask=mask,
                    )
        wc.generate_from_frequencies(frequencies = cloud_dict)
        
        # 將圖片存檔 提供下載使用
        pic_path = './static/images/' + text_font + cloud_imgg + datetime.datetime.now().strftime("%Y%m%d%H%M%S") + '.jpg'
        wc.to_file(pic_path)
        # 抓取要下載的檔案名 前端已改好 9487的預設值是留著作紀念(?) 可以直接改成request.values.get('file_name')
        file_name = request.values.get('file_name','9487還不命名') +'.jpg'
        # 選完 post 直接下載
        return send_file(pic_path, as_attachment=True, attachment_filename=file_name)
    # 還沒post 讓他選參數的頁面
    return render_template('文字雲_預設圖_下載.html')

# 文字雲_預設圖 上傳詞頻檔案
@app.route("/cloud_default_upload", methods=['POST','GET'])
def cloud_default_upload():
    if request.method == 'POST':
        # 抓檔案
        myFile = request.files.get('excelFile', None)
        # 把檔案先讀到df
        excel_data = pd.read_excel(myFile)
        # output_file_name 是存檔案在資料夾 提供後面存取
        # 頁面要加說明 讓使用者上傳檔案前 檔名加上自己的名字 避免後端檔案衝突
        output_file_name = myFile.filename.split('.')[0] + datetime.datetime.now().strftime("%Y%m%d%H%M%S") + '.xlsx'
        # 將上傳資料存到本機
        excel_data.to_excel(output_file_name)
        # 處理完直接跳下一個頁面 讓檔案名透過jinjia2傳遞
        return render_template('文字雲_預設圖_下載.html', read_file_name=output_file_name)
    return render_template('文字雲_預設圖.html')

		

# 文字雲_自定義_下載 複寫文字雲寫顏色需要的function
# 直接抄github複寫 更改有中文註解
# github: https://github.com/amueller/word_cloud/blob/master/wordcloud/wordcloud.py
def get_single_color_func(color):
    """Create a color function which returns a single hue and saturation with.
    different values (HSV). Accepted values are color strings as usable by
    PIL/Pillow.
    >>> color_func1 = get_single_color_func('deepskyblue')
    >>> color_func2 = get_single_color_func('#00b4d2')
    """
    old_r, old_g, old_b = ImageColor.getrgb(color)
    rgb_max = 255.
    h, s, v = colorsys.rgb_to_hsv(old_r / rgb_max, old_g / rgb_max,
                                  old_b / rgb_max)

    def single_color_func(word=None, font_size=None, position=None,
                          orientation=None, font_path=None, random_state=None):
        """Random color generation.
        Additional coloring method. It picks a random value with hue and
        saturation based on the color given to the generating function.
        Parameters
        ----------
        word, font_size, position, orientation  : ignored.
        random_state : random.Random object or None, (default=None)
          If a random object is given, this is used for generating random
          numbers.
        """
        # if random_state is None:
        #     random_state = Random()
        # 原本有random調整明暗度 現在整個拿掉 讓文字雲顏色統一
        r, g, b = colorsys.hsv_to_rgb(h, s, v)#random_state.uniform(1, 1)) 原本是random明暗度 被我拿掉 
        return 'rgb({:.0f}, {:.0f}, {:.0f})'.format(r * rgb_max, g * rgb_max,
                                                    b * rgb_max)
    return single_color_func

# 文字雲_自定義_下載 改顏色用的
# github 直接抄 因為好像套件本身沒有 要另外寫
# github: https://github.com/amueller/word_cloud/blob/master/examples/colored_by_group.py
class GroupedColorFunc(object):
    """Create a color function object which assigns DIFFERENT SHADES of
       specified colors to certain words based on the color to words mapping.

       Uses wordcloud.get_single_color_func

       Parameters
       ----------
       color_to_words : dict(str -> list(str))
         A dictionary that maps a color to the list of words.

       default_color : str
         Color that will be assigned to a word that's not a member
         of any value from color_to_words.
    """

    def __init__(self, color_to_words, default_color):
        self.color_func_to_words = [
            (get_single_color_func(color), set(words))
            for (color, words) in color_to_words.items()]

        self.default_color_func = get_single_color_func(default_color)

    def get_color_func(self, word):
        """Returns a single_color_func associated with the word"""
        try:
            color_func = next(
                color_func for (color_func, words) in self.color_func_to_words
                if word in words)
        except StopIteration:
            color_func = self.default_color_func

        return color_func

    def __call__(self, word, **kwargs):
        return self.get_color_func(word)(word, **kwargs)


# 文字雲_自定義_下載 吃前一頁面存檔的檔案名 調參數 產文字雲 直接下載
@app.route("/cloud_define_download/<read_file_name>", methods=['POST','GET'])
def cloud_define_download(read_file_name):
    if request.method == 'POST':
    	# 選擇字體
    	# 沒選的話 預設黑體
        text_font = request.values.get('fonttype','word_black')
        if text_font == "word_light":
            cloud_font = "./static/font/NotoSansCJKtc-Light.otf"
        else:
        	cloud_font = "./static/font/NotoSansCJKtc-Black.otf"
        # 上傳圖片 沒選的話 預設圓形(文字雲圖形)
        cloud_imgg = request.files.get('my_photo', None)
        pic_name = 'default_circle' + datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        # 儲存上傳的圖片 到./static/photo
        if cloud_imgg != None:
        	# 把上傳圖片檔名加上目前時間再儲存到本機 提供製作文字雲遮罩 避免重複或覆蓋 
            pic_name = cloud_imgg.filename.split('.')[0] + datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            img_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'static/photo/'+pic_name+'.jpg')
            cloud_imgg.save(img_path)
        # 讀本機檔 檔案名是前一頁面下載的檔案名
        word_fre_file = './'+ read_file_name
        word_fre_data = pd.read_excel(word_fre_file)
        # 抓標籤 製作更改顏色用的dict
        label = word_fre_data['標籤']
        label = label.drop_duplicates(keep='first', inplace=False)
        label = label.tolist()

        # 抓 選取的顏色
        color_pick = request.form.getlist('color_pick')
        # 將標籤&顏色編成dict
        label_color = {}
        for i in range(len(color_pick)):
            label_color[label[i]] = color_pick[i]

        # 做成 文字雲要吃的 color_to_words
        color_to_words ={}
        for k,v in label_color.items():
            column_data = word_fre_data[word_fre_data['標籤']==k]
            column_data = column_data['名詞'].tolist()
            color_to_words[v] = column_data

        # 整理出要製成文字雲的詞頻 做成dict
        cloud_word_frequen = word_fre_data[['名詞','詞頻']]
        cloud_dict = {}
        for word,frequen in cloud_word_frequen.values:
            cloud_dict[word] = frequen

        # 處理文字雲遮罩(圖片)
        if cloud_imgg == None:
            d = os.path.dirname(os.path.realpath('__file__'))
            mask = np.array(Image.open(os.path.join(d, "./static/images/circle.jpg")))
        else:
            d = os.path.dirname(os.path.realpath('__file__'))
            mask = np.array(Image.open(os.path.join(d, img_path)))
        # 產文字雲
        wc= WordCloud(font_path=cloud_font, #設置字體 #要自由切換字體 4、5種
                    background_color="white", #背景顏色
                    max_words = 50,
                    width=1000, height=860,  
                    mask=mask,
                    )
        wc.generate_from_frequencies(frequencies = cloud_dict)
        # 沒標籤 或是選到同色的詞 預設為黑色
        default_color = '#000000'
        # 將原本的文字雲 換成 標籤定義的顏色
        grouped_color_func = GroupedColorFunc(color_to_words, default_color)
        wc.recolor(color_func=grouped_color_func)
        # 將圖片存檔 提供下載使用
        pic_path = './static/images/' + text_font + pic_name + '.jpg'
        wc.to_file(pic_path)
        # 抓取要下載的檔案名
        file_name = request.values.get('file_name','9487還不命名') +'.jpg'
        # 選完 post 直接下載
        return send_file(pic_path, as_attachment=True, attachment_filename=file_name)
    # 還沒post 讓他選參數的頁面
    return render_template('文字雲_自定義_下載.html')

# 文字雲_自定義 上傳詞頻檔案
@app.route("/cloud_define_upload", methods=['POST','GET'])
def cloud_define_upload():
    if request.method == 'POST':
        myFile = request.files.get('excelFile', None)
        # output_file_name 是存檔案在資料夾 提供後面存取
        # 頁面要加說明 讓使用者上傳檔案前 檔名加上自己的名字 避免後端檔案衝突
        output_file_name = myFile.filename.split('.')[0] + datetime.datetime.now().strftime("%Y%m%d%H%M%S") + '.xlsx'
        word_fre = pd.read_excel(myFile)
        word_fre.to_excel(output_file_name)
        # 抓出資料標籤 下一個頁面呈現 選顏色
        label = word_fre['標籤']
        label.drop_duplicates(keep='first', inplace=True)
        label = label.tolist()
        # 處理完直接跳下一個頁面 讓標籤透過jinjia2呈現
        return render_template('文字雲_自定義_下載.html', column_color=label, read_file_name=output_file_name)
    return render_template('文字雲_自定義.html')


if __name__ == "__main__":
    app.run(debug=True)